import 'package:flutter/material.dart';

import '../../dominio/entidades/avaliacao.dart';
import '../../dominio/entidades/disciplina.dart';
import '../../dominio/entidades/enums.dart';
import '../../dominio/entidades/estudante.dart';
import '../../dominio/entidades/inscricao.dart';

class ResultadoNota {
  final double nota;
  final String nomeEstudante;
  final String tipoAvaliacao;
  final String disciplina;

  const ResultadoNota({
    required this.nota,
    required this.nomeEstudante,
    required this.tipoAvaliacao,
    required this.disciplina,
  });
}

class GestaoEscolarController extends ChangeNotifier {
  int _contador = 0;

  final List<Estudante> estudantes = [];
  final List<Disciplina> disciplinas = [];
  final List<Inscricao> inscricoes = [];
  final List<Avaliacao> avaliacoes = [];

  String gerarId() {
    _contador++;
    return '${DateTime.now().millisecondsSinceEpoch}_$_contador';
  }

  Future<void> salvarEstudante(Estudante estudante) async {
    if (estudante.nome.trim().isEmpty || estudante.apelido.trim().isEmpty) {
      throw Exception('Informe o nome e o apelido do estudante.');
    }

    if (estudante.id.isEmpty) {
      estudantes.add(estudante.copyWith(id: gerarId()));
    } else {
      final index = estudantes.indexWhere((e) => e.id == estudante.id);
      if (index >= 0) {
        estudantes[index] = estudante;
      } else {
        estudantes.add(estudante);
      }
    }

    notifyListeners();
  }

  Future<void> removerEstudante(String id) async {
    estudantes.removeWhere((e) => e.id == id);
    inscricoes.removeWhere((i) => i.estudanteId == id);
    avaliacoes.removeWhere((a) => a.estudanteId == id);
    notifyListeners();
  }

  Future<void> salvarDisciplina(Disciplina disciplina) async {
    if (disciplina.nome.trim().isEmpty) {
      throw Exception('Informe o nome da disciplina.');
    }

    if (disciplina.id.isEmpty) {
      disciplinas.add(disciplina.copyWith(id: gerarId()));
    } else {
      final index = disciplinas.indexWhere((d) => d.id == disciplina.id);
      if (index >= 0) {
        disciplinas[index] = disciplina;
      } else {
        disciplinas.add(disciplina);
      }
    }

    notifyListeners();
  }

  Future<void> removerDisciplina(String id) async {
    disciplinas.removeWhere((d) => d.id == id);
    inscricoes.removeWhere((i) => i.disciplinaId == id);
    avaliacoes.removeWhere((a) => a.disciplinaId == id);
    notifyListeners();
  }

  Future<void> inscrever({
    required String estudanteId,
    required String disciplinaId,
  }) async {
    if (estudanteId.isEmpty || disciplinaId.isEmpty) {
      throw Exception('Selecione estudante e disciplina.');
    }

    final existe = inscricoes.any(
      (i) => i.estudanteId == estudanteId && i.disciplinaId == disciplinaId,
    );

    if (existe) {
      throw Exception('Este estudante já está inscrito nesta disciplina.');
    }

    inscricoes.add(
      Inscricao(
        id: gerarId(),
        estudanteId: estudanteId,
        disciplinaId: disciplinaId,
        dataInscricao: DateTime.now(),
      ),
    );

    notifyListeners();
  }

  Future<void> removerInscricao(String id) async {
    inscricoes.removeWhere((i) => i.id == id);
    notifyListeners();
  }

  Future<void> salvarAvaliacao(Avaliacao avaliacao) async {
    if (avaliacao.nota < 0 || avaliacao.nota > 20) {
      throw Exception('A nota deve estar entre 0 e 20.');
    }

    if (avaliacao.estudanteId.isEmpty || avaliacao.disciplinaId.isEmpty) {
      throw Exception('Selecione estudante e disciplina.');
    }

    if (avaliacao.id.isEmpty) {
      avaliacoes.add(avaliacao.copyWith(id: gerarId()));
    } else {
      final index = avaliacoes.indexWhere((a) => a.id == avaliacao.id);
      if (index >= 0) {
        avaliacoes[index] = avaliacao;
      } else {
        avaliacoes.add(avaliacao);
      }
    }

    notifyListeners();
  }

  Future<void> removerAvaliacao(String id) async {
    avaliacoes.removeWhere((a) => a.id == id);
    notifyListeners();
  }

  bool estaInscrito(String estudanteId, String disciplinaId) {
    return inscricoes.any(
      (i) => i.estudanteId == estudanteId && i.disciplinaId == disciplinaId,
    );
  }

  String nomeEstudante(String id) {
    final estudante = estudantes.where((e) => e.id == id).firstOrNull;
    return estudante?.nomeCompleto ?? 'Estudante removido';
  }

  String nomeDisciplina(String id) {
    final disciplina = disciplinas.where((d) => d.id == id).firstOrNull;
    return disciplina?.nome ?? 'Disciplina removida';
  }

  List<Estudante> estudantesInscritosNaDisciplina(String disciplinaId) {
    final ids = inscricoes
        .where((i) => i.disciplinaId == disciplinaId)
        .map((i) => i.estudanteId)
        .toSet();
    return estudantes.where((e) => ids.contains(e.id)).toList();
  }

  double mediaDisciplina(String disciplinaId) {
    final notas = avaliacoes.where((a) => a.disciplinaId == disciplinaId).toList();
    if (notas.isEmpty) return 0;
    return notas.map((a) => a.nota).reduce((a, b) => a + b) / notas.length;
  }

  double mediaEstudante(String estudanteId) {
    final notas = avaliacoes.where((a) => a.estudanteId == estudanteId).toList();
    if (notas.isEmpty) return 0;
    return notas.map((a) => a.nota).reduce((a, b) => a + b) / notas.length;
  }

  List<ResultadoNota> resultadosFormatados() {
    return avaliacoes.map((avaliacao) {
      return ResultadoNota(
        nota: avaliacao.nota,
        nomeEstudante: nomeEstudante(avaliacao.estudanteId),
        tipoAvaliacao: avaliacao.tipo.label,
        disciplina: nomeDisciplina(avaliacao.disciplinaId),
      );
    }).toList();
  }
}

extension FirstOrNullExtension<T> on Iterable<T> {
  T? get firstOrNull {
    final iterator = this.iterator;
    if (iterator.moveNext()) return iterator.current;
    return null;
  }
}
