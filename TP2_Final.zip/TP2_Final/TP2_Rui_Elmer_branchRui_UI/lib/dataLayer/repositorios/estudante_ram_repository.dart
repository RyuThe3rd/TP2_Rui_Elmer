import '../models/EstudanteModelo.dart';
import '../../dominio/entidades/estudante.dart';

class EstudanteRamRepository {
  int _proximoId = 0;
  final Map<String, EstudanteModelo> _dados = {};

  Future<void> salvar(Estudante estudante) async {
    final id = estudante.id.isEmpty ? (++_proximoId).toString() : estudante.id;
    _dados[id] = EstudanteModelo(
      id: id,
      nome: estudante.nome,
      apelido: estudante.apelido,
      curso: estudante.curso,
      dataDeInscricao: estudante.dataDeInscricao,
      turma: estudante.turma,
    );
  }

  Future<void> remover(String id) async {
    _dados.remove(id);
  }

  Future<List<Estudante>> listar({bool maisRecente = false}) async {
    final lista = _dados.values.toList();
    lista.sort((a, b) => maisRecente ? b.id.compareTo(a.id) : a.nome.compareTo(b.nome));
    return lista;
  }

  Future<Estudante?> buscarPorId(String id) async => _dados[id];
}
