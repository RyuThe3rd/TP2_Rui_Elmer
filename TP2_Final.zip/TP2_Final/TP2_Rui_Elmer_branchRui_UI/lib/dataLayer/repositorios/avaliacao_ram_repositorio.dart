import '../models/AvaliacaoModelo.dart';
import '../../dominio/entidades/avaliacao.dart';

class AvaliacaoRamRepository {
  int _proximoId = 0;
  final Map<String, AvaliacaoModelo> _dados = {};

  Future<void> salvar(Avaliacao avaliacao) async {
    final id = avaliacao.id.isEmpty ? (++_proximoId).toString() : avaliacao.id;
    _dados[id] = AvaliacaoModelo(
      id: id,
      tipo: avaliacao.tipo,
      estudante: avaliacao.estudante,
      estudanteId: avaliacao.estudanteId,
      data: avaliacao.data,
      disciplinaId: avaliacao.disciplinaId,
      nota: avaliacao.nota,
    );
  }

  Future<void> remover(String id) async {
    _dados.remove(id);
  }

  Future<List<Avaliacao>> listar() async {
    final lista = _dados.values.toList();
    lista.sort((a, b) => b.data.compareTo(a.data));
    return lista;
  }

  Future<Avaliacao?> buscarPorId(String id) async => _dados[id];
}
