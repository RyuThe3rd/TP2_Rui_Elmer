import '../models/DisciplinaModelo.dart';
import '../../dominio/entidades/disciplina.dart';

class DisciplinaRamRepository {
  int _proximoId = 0;
  final Map<String, DisciplinaModelo> _dados = {};

  Future<void> salvar(Disciplina disciplina) async {
    final id = disciplina.id.isEmpty ? (++_proximoId).toString() : disciplina.id;
    _dados[id] = DisciplinaModelo(
      id: id,
      nome: disciplina.nome,
      dataDeCriacao: disciplina.dataDeCriacao,
      curso: disciplina.curso,
      descricao: disciplina.descricao,
    );
  }

  Future<void> remover(String id) async {
    _dados.remove(id);
  }

  Future<List<Disciplina>> listar() async {
    final lista = _dados.values.toList();
    lista.sort((a, b) => a.nome.compareTo(b.nome));
    return lista;
  }

  Future<Disciplina?> buscarPorId(String id) async => _dados[id];
}
