class Estudante {
  String id;
  String nome;
  String apelido;
  DateTime dataDeInscricao;
  String turma;
  String curso;

  Estudante({
    String? id,
    required this.nome,
    required this.apelido,
    required this.dataDeInscricao,
    required this.turma,
    required this.curso,
  }) : id = id ?? '';

  String get nomeCompleto => '$nome $apelido'.trim();

  Estudante copyWith({
    String? id,
    String? nome,
    String? apelido,
    DateTime? dataDeInscricao,
    String? turma,
    String? curso,
  }) {
    return Estudante(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      apelido: apelido ?? this.apelido,
      dataDeInscricao: dataDeInscricao ?? this.dataDeInscricao,
      turma: turma ?? this.turma,
      curso: curso ?? this.curso,
    );
  }
}
