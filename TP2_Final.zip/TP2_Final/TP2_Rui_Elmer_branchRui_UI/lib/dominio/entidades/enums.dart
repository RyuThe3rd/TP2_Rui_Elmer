enum Avaliacoes { mt1, mt2, teste1, teste2, exame, recorrencia }

enum Curso { LECC, LEIT, OUTROS }

extension AvaliacoesExt on Avaliacoes {
  String get label {
    switch (this) {
      case Avaliacoes.mt1:
        return 'Mini Teste 1';
      case Avaliacoes.mt2:
        return 'Mini Teste 2';
      case Avaliacoes.teste1:
        return 'Teste 1';
      case Avaliacoes.teste2:
        return 'Teste 2';
      case Avaliacoes.exame:
        return 'Exame';
      case Avaliacoes.recorrencia:
        return 'Recorrência';
    }
  }
}
