import 'estudante.dart';

class Disciplina {
  static final List<Disciplina> disciplinas = [];

  String id;
  String nome;
  DateTime dataDeCriacao;
  String curso;
  String descricao;
  final List<Estudante> alunos;

  Disciplina({
    String? id,
    required this.nome,
    required this.dataDeCriacao,
    required this.curso,
    String? descricao,
    List<Estudante>? alunos,
  })  : id = id ?? '',
        descricao = descricao ?? '',
        alunos = alunos ?? [];

  Disciplina copyWith({
    String? id,
    String? nome,
    DateTime? dataDeCriacao,
    String? curso,
    String? descricao,
    List<Estudante>? alunos,
  }) {
    return Disciplina(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      dataDeCriacao: dataDeCriacao ?? this.dataDeCriacao,
      curso: curso ?? this.curso,
      descricao: descricao ?? this.descricao,
      alunos: alunos ?? this.alunos,
    );
  }
}
