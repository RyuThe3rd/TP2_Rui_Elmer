import 'enums.dart';

class Avaliacao {
  String id;
  Avaliacoes tipo;
  DateTime data;
  String estudante;
  String estudanteId;
  String disciplinaId;
  double nota;

  Avaliacao({
    String? id,
    required this.tipo,
    required this.estudante,
    required this.estudanteId,
    required this.data,
    required this.disciplinaId,
    required this.nota,
  }) : id = id ?? '';

  Avaliacao copyWith({
    String? id,
    Avaliacoes? tipo,
    DateTime? data,
    String? estudante,
    String? estudanteId,
    String? disciplinaId,
    double? nota,
  }) {
    return Avaliacao(
      id: id ?? this.id,
      tipo: tipo ?? this.tipo,
      estudante: estudante ?? this.estudante,
      estudanteId: estudanteId ?? this.estudanteId,
      data: data ?? this.data,
      disciplinaId: disciplinaId ?? this.disciplinaId,
      nota: nota ?? this.nota,
    );
  }
}
