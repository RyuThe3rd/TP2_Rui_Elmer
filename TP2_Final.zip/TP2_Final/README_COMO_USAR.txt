COMO USAR

1. Extrai este ZIP.
2. Copia a pasta lib e o ficheiro pubspec.yaml.
3. Cola/substitui dentro do projeto TP2_Rui_Elmer-branchRui.
4. No Android Studio, roda:

flutter clean
flutter pub get
flutter run

OBS: Este pacote usa a estrutura do branchRui: dominio, dataLayer, modelos e entidades.
